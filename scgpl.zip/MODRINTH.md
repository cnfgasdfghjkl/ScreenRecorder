# Modrinth 上架指南

## 一、注册/登录
1. 打开 https://modrinth.com
2. 点右上角登录，用 GitHub 账号授权登录

## 二、创建项目
登录后点右上角头像 → **Create a project**，填写：

| 字段 | 填什么 |
|------|--------|
| Project type | Mod |
| Gallery | 先上传截图（游戏内按 N 录制的画面、设置界面截图） |
| Title | Screen Recorder |
| Slug | screenrecorder（URL 用，别改） |
| Summary | 按 N 键原速录屏为 MP4，支持游戏声音+麦克风，Ctrl+N 调画质帧率 |
| Description | 粘贴 README.md 的内容（支持 Markdown） |
| Client side | Required（纯客户端模组） |
| Server side | Unsupported |
| License | **GPL-3.0** |
| Categories | utility, optimization, video-processing |
| Project icon | 用 `assets/screenrecorder/icon.png`（128x128） |

## 三、上传版本（版本发布）
项目创建后点 **Versions → Create a version**：

### 版本 1.0.1（1.20.x）：
| 字段 | 填什么 |
|------|--------|
| Version number | 1.0.1 |
| Version type | Release |
| Upload file | `screenrecorder-1.0.1-mc1.20.1.jar` |
| Supported game versions | 勾选 1.20.1, 1.20.2, 1.20.3, 1.20.4, 1.20.5, 1.20.6 |
| Loaders | Fabric |
| Dependencies | Fabric API（required）, Mod Menu（optional） |
| Release date | 今天 |

### 版本 1.0.1（1.21.x）：
| 字段 | 填什么 |
|------|--------|
| Version number | 1.0.1+1.21 |
| Upload file | `screenrecorder-1.0.1-mc1.21.1.jar` |
| Supported game versions | 勾选 1.21, 1.21.1 |
| Loaders | Fabric |
| Dependencies | Fabric API（required）, Mod Menu（optional） |

## 四、开源到 GitHub
1. 新建 GitHub 仓库，私有或公开都行
2. 把 `screenrecorder-source-gpl.zip` 解压后所有文件 push 上去（删掉 build/ 和 .gradle/）
3. GitHub 仓库 Settings → 把仓库 topics 加：`minecraft` `fabric` `mod` `recording` `screen-recorder`
4. Modrinth 项目页面填 Source 链接 = GitHub 仓库地址

## 五、构建命令（给其他贡献者看）
```bash
# 1.20.x 需要 JDK 17
# 1.21.x 需要 JDK 21
gradle build --no-daemon
# jar 输出在 build/libs/
```
