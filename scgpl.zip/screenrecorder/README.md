# Screen Recorder — 屏幕录制模组 v1.0.1

按 **N 键**开始/停止录屏，**Ctrl+N** 打开设置界面。原速录制，用户卡顿也录进去。支持录制游戏声音和麦克风。

## 支持版本
- **1.20.x**：使用 `screenrecorder-1.0.1-mc1.20.1.jar`
- **1.21.x**：使用 `screenrecorder-1.0.1-mc1.21.1.jar`
- fabric.mod.json 声明兼容 1.20~1.21.99，分别编译确保稳定

## 功能
- **N 键**：切换录屏（开始/停止）
- **Ctrl+N**：打开设置界面
- 原速录制：每帧都捕获，不跳帧不加速，用户卡顿也录进去（FFmpeg wallclock 时间戳）
- 录制中屏幕底部显示 `● 录制中 00:03 (854x480, 30fps) 按 N 停止`（开音频会显示 ♪/🎤）
- 输出 MP4（H.264 + AAC），保存到 `.minecraft/screenshots/`

## 设置界面（Ctrl+N 或 Mod Menu 配置按钮）
- **画质**：160P / 480P / 720P / 1080P / 2K / 4K（默认 480P，宽度按游戏比例缩放）
- **帧率**：10 / 15 / 20 / 30 / 45 / 60 / 90（默认 30fps）
- **录制游戏声音**：开/关（默认关）
- **录制麦克风**：开/关（默认关）
- 配置保存到 `.minecraft/config/screenrecorder.json`

## 安装
1. 确认已装 **Fabric API**（对应版本）
2. 根据游戏版本选择对应 jar，丢进 `mods/` 文件夹
3. （可选）安装 **Mod Menu**，可在模组列表中点"配置"打开设置
4. 重启游戏

## ⚠️ 必须安装 FFmpeg
本模组通过调用系统 **ffmpeg** 编码视频和音频，没有 ffmpeg 无法录制。

### PC
- Windows：下载 ffmpeg，把 `ffmpeg.exe` 所在目录加入系统 PATH
- Mac：`brew install ffmpeg`
- Linux：`sudo apt install ffmpeg`

### 安卓 FCL / Termux
```bash
pkg install ffmpeg
```

## 音频录制说明
音频录制依赖 FFmpeg 访问系统音频设备，不同平台配置不同：

| 平台 | 系统声音 | 麦克风 | 说明 |
|------|---------|--------|------|
| Windows | dshow | dshow | 系统声音需立体声混音或虚拟声卡（如 VB-Cable） |
| Linux | pulse | pulse | 用 PulseAudio 默认设备，可在配置文件指定设备名 |
| Mac | avfoundation | avfoundation | 系统声音需 BlackHole 等虚拟音频设备 |
| 安卓 | 受限 | 受限 | 系统音频基本不可用，麦克风可能需额外配置 |

### 自定义音频设备
如果默认设备不对，编辑 `.minecraft/config/screenrecorder.json`，填写：
```json
{
  "gameAudioDevice": "你的系统音频设备名",
  "micDevice": "你的麦克风设备名"
}
```
- Windows dshow 设备名格式：`麦克风 (Realtek Audio)`（不带 `audio=` 前缀）
- Linux pulse 设备名：`default` 或具体设备名（可用 `pactl list sources` 查看）

### 同时录制游戏声音+麦克风
两路音频会通过 FFmpeg amix 自动混合，输出为单路音轨。

### 音频录制失败
如果音频设备不存在，FFmpeg 会启动失败，聊天栏提示错误。此时可在设置界面关闭音频选项，纯视频录制不受影响。

## 使用
1. （可选）按 **Ctrl+N** 调整画质、帧率、音频开关
2. 按 **N** 开始录制
3. 再按 **N** 停止，聊天栏显示文件名和大小
4. 去 `.minecraft/screenshots/` 找 MP4 文件

## 常见问题
**Q: Ctrl+N 没反应？**
A: v1.0.1 已修复，改用 GLFW 底层直接检测 Ctrl 键。确保是在游戏中（没打开其他界面）按。

**Q: 按 N 提示启动失败？**
A: 大概率是没装 ffmpeg 或音频设备不存在。看聊天栏错误提示。音频问题可先关闭音频选项试。

**Q: 录制的视频很卡？**
A: 原速录制，游戏卡视频也会卡（真实还原）。想流畅请降低渲染距离或选低分辨率。

**Q: 视频没有声音？**
A: 需要在设置界面开启"录制游戏声音"或"录制麦克风"，并确保系统音频设备可用。

**Q: FCL 安卓上能录音频吗？**
A: 系统音频在安卓上基本不可用（需 root），麦克风可能可用但配置复杂。建议安卓上只录视频。

## 技术信息
- 版本：1.0.1
- 支持：Minecraft 1.20.x ~ 1.21.x + Fabric + Fabric API
- Java：17（1.20.x）/ 21（1.21.x）
- 视频编码：FFmpeg libx264，CRF 23，preset veryfast
- 音频编码：AAC 128kbps，44100Hz
- 捕获：glReadPixels 主帧缓冲，BGRA 管道喂 ffmpeg
- 时间戳：wallclock 原速，输出恒定帧率（-vsync cfr）
