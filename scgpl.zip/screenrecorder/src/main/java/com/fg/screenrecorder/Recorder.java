package com.fg.screenrecorder;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL12;

import java.io.*;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * 屏幕录制核心：
 * - 原速录制：每帧都捕获，不跳帧，用户卡顿也录进去
 * - FFmpeg wallclock 时间戳保证视频速度 = 实时速度
 * - 支持分辨率缩放
 * - 支持音频录制（系统声音 + 麦克风，可混合）
 */
public class Recorder {
    private Process ffmpegProcess;
    private OutputStream ffmpegStdin;
    private boolean recording = false;
    private int srcWidth, srcHeight;
    private int outWidth, outHeight;
    private ByteBuffer frameBuffer;
    private byte[] flipSrc;
    private byte[] flipDst;
    private File outputFile;
    private long startTime;
    private int frameCount = 0;
    private String ffmpegError = "";
    private int targetFps = 30;
    private boolean audioEnabled = false;
    private boolean micEnabled = false;

    public boolean isRecording() { return recording; }
    public int getFrameCount() { return frameCount; }
    public long getElapsedMillis() { return System.currentTimeMillis() - startTime; }
    public String getFfmpegError() { return ffmpegError; }
    public boolean isAudioEnabled() { return audioEnabled; }
    public boolean isMicEnabled() { return micEnabled; }

    public static boolean checkFFmpeg() {
        try {
            Process p = new ProcessBuilder("ffmpeg", "-version").start();
            p.waitFor();
            return p.exitValue() == 0;
        } catch (Exception e) {
            return false;
        }
    }

    /** 检测当前操作系统 */
    private static String detectOS() {
        String os = System.getProperty("os.name", "").toLowerCase();
        if (os.contains("win")) return "windows";
        if (os.contains("mac")) return "mac";
        // 安卓检测
        if (new File("/system/build.prop").exists()
            || System.getProperty("java.vendor", "").toLowerCase().contains("android")) {
            return "android";
        }
        return "linux";
    }

    /**
     * 根据平台和配置构建音频输入参数
     * @return 音频输入参数列表，以及是否需要 amix 混合
     */
    private static class AudioSetup {
        List<String> inputArgs = new ArrayList<>();
        List<String> outputArgs = new ArrayList<>();
        boolean hasAudio = false;
        boolean mixed = false;
    }

    private static AudioSetup buildAudioArgs(ModConfig config) {
        AudioSetup setup = new AudioSetup();
        boolean needGame = config.isRecordAudio();
        boolean needMic = config.isRecordMic();
        if (!needGame && !needMic) return setup;

        String os = detectOS();
        String format;
        String gameDev, micDev;

        switch (os) {
            case "windows":
                format = "dshow";
                gameDev = config.getGameAudioDevice().isEmpty()
                    ? "audio=virtual-audio-capturer"
                    : "audio=" + config.getGameAudioDevice();
                micDev = config.getMicDevice().isEmpty()
                    ? "audio=microphone"
                    : "audio=" + config.getMicDevice();
                break;
            case "mac":
                format = "avfoundation";
                gameDev = config.getGameAudioDevice().isEmpty() ? ":0" : ":" + config.getGameAudioDevice();
                micDev = config.getMicDevice().isEmpty() ? ":1" : ":" + config.getMicDevice();
                break;
            case "android":
                // 安卓上系统音频录制受限，麦克风可能可用
                format = "pulse";
                gameDev = config.getGameAudioDevice().isEmpty() ? "default" : config.getGameAudioDevice();
                micDev = config.getMicDevice().isEmpty() ? "default" : config.getMicDevice();
                break;
            default: // linux
                format = "pulse";
                gameDev = config.getGameAudioDevice().isEmpty() ? "default" : config.getGameAudioDevice();
                micDev = config.getMicDevice().isEmpty() ? "default" : config.getMicDevice();
                break;
        }

        setup.hasAudio = true;
        if (needGame && needMic) {
            // 两路音频输入
            setup.inputArgs.add("-f"); setup.inputArgs.add(format);
            setup.inputArgs.add("-i"); setup.inputArgs.add(gameDev);
            setup.inputArgs.add("-f"); setup.inputArgs.add(format);
            setup.inputArgs.add("-i"); setup.inputArgs.add(micDev);
            // amix 混合
            setup.outputArgs.add("-filter_complex");
            setup.outputArgs.add("[1:a][2:a]amix=inputs=2:duration=longest:dropout_transition=0[a]");
            setup.outputArgs.add("-map"); setup.outputArgs.add("0:v");
            setup.outputArgs.add("-map"); setup.outputArgs.add("[a]");
            setup.mixed = true;
        } else {
            // 单路音频
            String dev = needGame ? gameDev : micDev;
            setup.inputArgs.add("-f"); setup.inputArgs.add(format);
            setup.inputArgs.add("-i"); setup.inputArgs.add(dev);
        }
        // 音频编码
        setup.outputArgs.add("-c:a"); setup.outputArgs.add("aac");
        setup.outputArgs.add("-b:a"); setup.outputArgs.add("128k");
        setup.outputArgs.add("-ar"); setup.outputArgs.add("44100");

        return setup;
    }

    /**
     * 开始录制
     */
    public boolean start(int targetHeight, int fps, ModConfig config) {
        if (recording) return false;
        this.targetFps = fps;
        this.audioEnabled = config.isRecordAudio();
        this.micEnabled = config.isRecordMic();

        MinecraftClient mc = MinecraftClient.getInstance();
        Framebuffer fbo = mc.getFramebuffer();
        srcWidth = fbo.textureWidth;
        srcHeight = fbo.textureHeight;
        if (srcWidth <= 0 || srcHeight <= 0) return false;

        // 按比例计算输出宽度，对齐到偶数
        outHeight = targetHeight;
        outWidth = (int) Math.round((double) srcWidth * targetHeight / srcHeight);
        if (outWidth % 2 != 0) outWidth++;
        if (outHeight % 2 != 0) outHeight++;

        frameBuffer = ByteBuffer.allocateDirect(srcWidth * srcHeight * 4);
        flipSrc = new byte[srcWidth * srcHeight * 4];
        flipDst = new byte[srcWidth * srcHeight * 4];

        // 输出文件
        File screenshotsDir = new File(mc.runDirectory, "screenshots");
        if (!screenshotsDir.exists()) screenshotsDir.mkdirs();
        String timestamp = new SimpleDateFormat("yyyy-MM-dd_HH.mm.ss").format(new Date());
        outputFile = new File(screenshotsDir, "recording_" + timestamp + ".mp4");

        if (!checkFFmpeg()) {
            ffmpegError = "未检测到 ffmpeg，请先安装 ffmpeg";
            return false;
        }

        // 构建音频参数
        AudioSetup audio = buildAudioArgs(config);

        try {
            List<String> cmd = new ArrayList<>();
            cmd.add("ffmpeg"); cmd.add("-y");
            // 视频输入（原始帧）
            cmd.add("-f"); cmd.add("rawvideo");
            cmd.add("-pix_fmt"); cmd.add("bgra");
            cmd.add("-s"); cmd.add(srcWidth + "x" + srcHeight);
            cmd.add("-use_wallclock_as_timestamps"); cmd.add("1");
            cmd.add("-i"); cmd.add("-");
            // 音频输入
            cmd.addAll(audio.inputArgs);
            // 视频编码
            cmd.add("-vf"); cmd.add("scale=" + outWidth + ":" + outHeight);
            cmd.add("-c:v"); cmd.add("libx264");
            cmd.add("-preset"); cmd.add("veryfast");
            cmd.add("-crf"); cmd.add("23");
            cmd.add("-pix_fmt"); cmd.add("yuv420p");
            cmd.add("-r"); cmd.add(fps + "");
            cmd.add("-vsync"); cmd.add("cfr");
            // 音频输出参数（含 map/filter）
            cmd.addAll(audio.outputArgs);
            // 输出
            cmd.add("-movflags"); cmd.add("+faststart");
            cmd.add("-shortest");  // 音频比视频长时截断
            cmd.add(outputFile.getAbsolutePath());

            ProcessBuilder pb = new ProcessBuilder(cmd);
            pb.redirectErrorStream(false);
            ffmpegProcess = pb.start();
            ffmpegStdin = new BufferedOutputStream(ffmpegProcess.getOutputStream());
            recording = true;
            startTime = System.currentTimeMillis();
            frameCount = 0;
            ffmpegError = "";
            return true;
        } catch (IOException e) {
            ffmpegError = "启动 ffmpeg 失败: " + e.getMessage();
            e.printStackTrace();
            return false;
        }
    }

    /** 每帧渲染完成后调用，捕获当前画面（原速：每帧都捕获） */
    public void captureFrame() {
        if (!recording) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null) return;

        try {
            Framebuffer fbo = mc.getFramebuffer();
            fbo.beginRead();
            frameBuffer.clear();
            GL11.glReadPixels(0, 0, srcWidth, srcHeight, GL12.GL_BGRA, GL11.GL_UNSIGNED_BYTE, frameBuffer);
            fbo.endRead();

            // 垂直翻转
            frameBuffer.get(flipSrc);
            int stride = srcWidth * 4;
            for (int y = 0; y < srcHeight; y++) {
                System.arraycopy(flipSrc, (srcHeight - 1 - y) * stride, flipDst, y * stride, stride);
            }

            ffmpegStdin.write(flipDst);
            frameCount++;
        } catch (Exception e) {
            ffmpegError = "写入帧失败: " + e.getMessage();
        }
    }

    /** 停止录制，返回输出文件 */
    public File stop() {
        if (!recording) return null;
        recording = false;
        try {
            ffmpegStdin.flush();
            ffmpegStdin.close();
            ffmpegProcess.waitFor();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return outputFile;
    }

    public int getOutWidth() { return outWidth; }
    public int getOutHeight() { return outHeight; }
    public int getTargetFps() { return targetFps; }
}
