package com.fg.screenrecorder;

import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;

/**
 * Mod Menu 集成：在模组列表中点击"配置"按钮打开设置界面。
 * 仅在用户安装了 Mod Menu 时生效，未安装时不影响模组运行。
 */
public class ModMenuIntegration implements ModMenuApi {
    @Override
    public ConfigScreenFactory<?> getModConfigScreenFactory() {
        return parent -> new SettingsScreen(parent, ScreenRecorderMod.getConfig());
    }
}
