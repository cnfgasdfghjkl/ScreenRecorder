package com.fg.screenrecorder;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

/**
 * 录屏设置界面（Ctrl+N 打开）
 * 画质选择 + 帧率选择，点击按钮循环切换
 */
public class SettingsScreen extends Screen {
    private final Screen parent;
    private final ModConfig config;

    public SettingsScreen(Screen parent, ModConfig config) {
        super(Text.literal("录屏设置"));
        this.parent = parent;
        this.config = config;
    }

    @Override
    protected void init() {
        int centerX = this.width / 2;
        int y = this.height / 2 - 80;
        int btnH = 20;
        int gap = 4;

        // 画质按钮
        this.addDrawableChild(ButtonWidget.builder(
            Text.literal("画质: " + config.getResolution()),
            btn -> {
                config.nextResolution();
                btn.setMessage(Text.literal("画质: " + config.getResolution()));
            }
        ).dimensions(centerX - 100, y, 200, btnH).build());
        y += btnH + gap;

        // 帧率按钮
        this.addDrawableChild(ButtonWidget.builder(
            Text.literal("帧率: " + config.getFps() + " fps"),
            btn -> {
                config.nextFps();
                btn.setMessage(Text.literal("帧率: " + config.getFps() + " fps"));
            }
        ).dimensions(centerX - 100, y, 200, btnH).build());
        y += btnH + gap;

        // 系统音频（游戏声音）
        this.addDrawableChild(ButtonWidget.builder(
            Text.literal("录制游戏声音: " + (config.isRecordAudio() ? "§a开" : "§c关")),
            btn -> {
                config.toggleRecordAudio();
                btn.setMessage(Text.literal("录制游戏声音: " + (config.isRecordAudio() ? "§a开" : "§c关")));
            }
        ).dimensions(centerX - 100, y, 200, btnH).build());
        y += btnH + gap;

        // 麦克风
        this.addDrawableChild(ButtonWidget.builder(
            Text.literal("录制麦克风: " + (config.isRecordMic() ? "§a开" : "§c关")),
            btn -> {
                config.toggleRecordMic();
                btn.setMessage(Text.literal("录制麦克风: " + (config.isRecordMic() ? "§a开" : "§c关")));
            }
        ).dimensions(centerX - 100, y, 200, btnH).build());
        y += btnH + gap + 8;

        // 保存并返回
        this.addDrawableChild(ButtonWidget.builder(
            Text.literal("保存并返回"),
            btn -> {
                config.save();
                this.client.setScreen(parent);
            }
        ).dimensions(centerX - 100, y, 200, btnH).build());
        y += btnH + gap;

        // 取消
        this.addDrawableChild(ButtonWidget.builder(
            Text.literal("取消"),
            btn -> this.client.setScreen(parent)
        ).dimensions(centerX - 100, y, 200, btnH).build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackgroundCompat(context, mouseX, mouseY, delta);
        super.render(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 20, 0xFFFFFF);
        context.drawCenteredTextWithShadow(this.textRenderer,
            Text.literal("§7点击按钮循环切换选项"),
            this.width / 2, this.height / 2 - 72, 0xAAAAAA);
    }

    /** 跨版本兼容：1.20.1 用 renderBackground(DrawContext)，1.20.2+ 用四参数版本 */
    private void renderBackgroundCompat(DrawContext context, int mouseX, int mouseY, float delta) {
        try {
            // 尝试四参数版本（1.20.2+ / 1.21）
            java.lang.reflect.Method m = Screen.class.getMethod("renderBackground",
                DrawContext.class, int.class, int.class, float.class);
            m.invoke(this, context, mouseX, mouseY, delta);
        } catch (NoSuchMethodException e) {
            try {
                // 回退单参数版本（1.20.1）
                java.lang.reflect.Method m = Screen.class.getMethod("renderBackground", DrawContext.class);
                m.invoke(this, context);
            } catch (Exception ignored) {}
        } catch (Exception ignored) {}
    }

    @Override
    public boolean shouldPause() {
        return true;
    }
}
