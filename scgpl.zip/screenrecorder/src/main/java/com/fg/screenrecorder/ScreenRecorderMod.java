package com.fg.screenrecorder;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.io.File;

public class ScreenRecorderMod implements ClientModInitializer {
    public static final String MOD_ID = "screenrecorder";
    private static final Recorder recorder = new Recorder();
    static ModConfig config;
    private static boolean nWasDown = false;  // 跟踪 N 键状态，检测上升沿

    /** 供 Mod Menu 等外部获取配置 */
    public static ModConfig getConfig() { return config; }

    @Override
    public void onInitializeClient() {
        config = ModConfig.load();

        // 每帧渲染完成后捕获画面（原速：每帧都捕获，不跳过）
        WorldRenderEvents.LAST.register(context -> recorder.captureFrame());

        // 客户端 tick：检测按键 + 显示录制状态
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            // 录制中：屏幕底部中央显示红色录制指示 + 时长 + 分辨率/帧率 + 音频状态
            if (recorder.isRecording()) {
                long sec = recorder.getElapsedMillis() / 1000;
                String time = String.format("%02d:%02d", sec / 60, sec % 60);
                String audioTag = "";
                if (recorder.isAudioEnabled()) audioTag += " §d♪";
                if (recorder.isMicEnabled()) audioTag += " §b🎤";
                client.inGameHud.setOverlayMessage(
                    Text.literal("§c● 录制中 " + time
                        + "  §7(" + recorder.getOutWidth() + "x" + recorder.getOutHeight()
                        + ", " + recorder.getTargetFps() + "fps)" + audioTag + "  §f按 N 停止"),
                    false
                );
            }

            // 只在游戏主界面（无打开的屏幕）处理 N 键
            if (client.currentScreen == null) {
                long handle = client.getWindow().getHandle();
                boolean nDown = GLFW.glfwGetKey(handle, GLFW.GLFW_KEY_N) == GLFW.GLFW_PRESS;
                // 用 GLFW 直接检测左右 Ctrl，比 Screen.hasControlDown() 更可靠
                boolean ctrlDown = GLFW.glfwGetKey(handle, GLFW.GLFW_KEY_LEFT_CONTROL) == GLFW.GLFW_PRESS
                                || GLFW.glfwGetKey(handle, GLFW.GLFW_KEY_RIGHT_CONTROL) == GLFW.GLFW_PRESS;

                // N 键上升沿（刚按下的一帧）
                if (nDown && !nWasDown) {
                    if (ctrlDown) {
                        // Ctrl+N 打开设置界面
                        client.setScreen(new SettingsScreen(null, config));
                    } else {
                        // N 切换录屏
                        toggleRecording();
                    }
                }
                nWasDown = nDown;
            } else {
                nWasDown = false;  // 有屏幕打开时重置状态
            }
        });
    }

    private void toggleRecording() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (recorder.isRecording()) {
            // 停止录制
            File file = recorder.stop();
            if (file != null && file.exists()) {
                long sizeKB = file.length() / 1024;
                mc.inGameHud.getChatHud().addMessage(
                    Text.literal("§a[录屏] §f录制结束 §7(" + recorder.getFrameCount()
                        + "帧, " + sizeKB + "KB)§f 已保存: §b" + file.getName())
                );
            } else {
                mc.inGameHud.getChatHud().addMessage(
                    Text.literal("§c[录屏] §f录制结束，但输出文件未找到")
                );
            }
        } else {
            // 开始录制（用当前配置）
            boolean started = recorder.start(config.getTargetHeight(), config.getFps(), config);
            if (started) {
                String audioInfo = "";
                if (config.isRecordAudio()) audioInfo += " 游戏声音";
                if (config.isRecordMic()) audioInfo += " 麦克风";
                if (audioInfo.isEmpty()) audioInfo = " 无音频";
                mc.inGameHud.getChatHud().addMessage(
                    Text.literal("§a[录屏] §f开始录制 §7(" + config.getResolution()
                        + ", " + config.getFps() + "fps, 原速," + audioInfo + ")§f 保存到 screenshots，按 §bN §f停止")
                );
            } else {
                String err = recorder.getFfmpegError();
                mc.inGameHud.getChatHud().addMessage(
                    Text.literal("§c[录屏] §f启动失败！" + (err.isEmpty() ? "" : err))
                );
                mc.inGameHud.getChatHud().addMessage(
                    Text.literal("§7提示：需要安装 ffmpeg。PC 端直接装 ffmpeg；安卓 Termux 执行 pkg install ffmpeg")
                );
            }
        }
    }
}
