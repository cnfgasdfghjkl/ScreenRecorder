package com.fg.screenrecorder;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.minecraft.client.MinecraftClient;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

/**
 * 录屏配置：分辨率档位 + 帧率，保存到 .minecraft/config/screenrecorder.json
 */
public class ModConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static File configFile;

    // 分辨率档位（高度）
    public static final String[] RESOLUTIONS = {"160P", "480P", "720P", "1080P", "2K", "4K"};
    public static final int[] RES_HEIGHTS = {160, 480, 720, 1080, 1440, 2160};

    // 帧率档位
    public static final int[] FPS_OPTIONS = {10, 15, 20, 30, 45, 60, 90};

    private String resolution = "480P";  // 默认 480P
    private int fps = 30;                  // 默认 30fps
    private boolean recordAudio = false;   // 录制系统音频（游戏声音）
    private boolean recordMic = false;     // 录制麦克风（自己的声音）
    private String gameAudioDevice = "";   // 系统音频设备名（空=自动检测）
    private String micDevice = "";          // 麦克风设备名（空=自动检测）

    public String getResolution() { return resolution; }
    public int getFps() { return fps; }
    public boolean isRecordAudio() { return recordAudio; }
    public boolean isRecordMic() { return recordMic; }
    public String getGameAudioDevice() { return gameAudioDevice; }
    public String getMicDevice() { return micDevice; }
    public void setResolution(String r) { this.resolution = r; }
    public void setFps(int f) { this.fps = f; }
    public void setRecordAudio(boolean v) { this.recordAudio = v; }
    public void setRecordMic(boolean v) { this.recordMic = v; }

    /** 获取当前分辨率档位对应的目标高度 */
    public int getTargetHeight() {
        for (int i = 0; i < RESOLUTIONS.length; i++) {
            if (RESOLUTIONS[i].equals(resolution)) return RES_HEIGHTS[i];
        }
        return 480;
    }

    /** 切换到下一个分辨率档位 */
    public void nextResolution() {
        for (int i = 0; i < RESOLUTIONS.length; i++) {
            if (RESOLUTIONS[i].equals(resolution)) {
                resolution = RESOLUTIONS[(i + 1) % RESOLUTIONS.length];
                return;
            }
        }
        resolution = "480P";
    }

    /** 切换到下一个帧率档位 */
    public void nextFps() {
        for (int i = 0; i < FPS_OPTIONS.length; i++) {
            if (FPS_OPTIONS[i] == fps) {
                fps = FPS_OPTIONS[(i + 1) % FPS_OPTIONS.length];
                return;
            }
        }
        fps = 30;
    }

    /** 切换系统音频录制 */
    public void toggleRecordAudio() { this.recordAudio = !this.recordAudio; }

    /** 切换麦克风录制 */
    public void toggleRecordMic() { this.recordMic = !this.recordMic; }

    public static ModConfig load() {
        MinecraftClient mc = MinecraftClient.getInstance();
        File configDir = new File(mc.runDirectory, "config");
        if (!configDir.exists()) configDir.mkdirs();
        configFile = new File(configDir, "screenrecorder.json");

        if (configFile.exists()) {
            try (FileReader reader = new FileReader(configFile)) {
                ModConfig cfg = GSON.fromJson(reader, ModConfig.class);
                if (cfg != null) {
                    // 校验值合法性
                    boolean valid = false;
                    for (String r : RESOLUTIONS) if (r.equals(cfg.resolution)) valid = true;
                    if (!valid) cfg.resolution = "480P";
                    boolean fpsValid = false;
                    for (int f : FPS_OPTIONS) if (f == cfg.fps) fpsValid = true;
                    if (!fpsValid) cfg.fps = 30;
                    return cfg;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return new ModConfig();
    }

    public void save() {
        if (configFile == null) {
            MinecraftClient mc = MinecraftClient.getInstance();
            File configDir = new File(mc.runDirectory, "config");
            if (!configDir.exists()) configDir.mkdirs();
            configFile = new File(configDir, "screenrecorder.json");
        }
        try (FileWriter writer = new FileWriter(configFile)) {
            GSON.toJson(this, writer);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
